# -*- coding: utf-8 -*-
"""
Created on Fri Jun 17 15:44:35 2022

@author: kbebim05
"""
import numpy as np

# Yayma Operasyonu

def naive_add_matrix_and_vector(x, y):
    assert len(x.shape) == 2
    assert len(y.shape) == 1
    assert x.shape[1] == y.shape[0]
    
    x = x.copy()
    
    for i in range(x.shape[0]):
        for j in range(x.shape[1]):
            x[i, j] += y[j]
    return x

x = np.array([[7, 14, 21],
               [7, 14 ,21],
              [7, 14 ,21]])

y = np.array([1, 2, 3])

z = naive_add_matrix_and_vector(x, y)
print(z)

