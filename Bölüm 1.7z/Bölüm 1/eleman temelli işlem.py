# -*- coding: utf-8 -*-
"""
Created on Fri Jun 17 14:13:49 2022

@author: kbebim05
"""
import numpy as np

# Eleman Temelli İşlem

# def naive_add(x, y):
#     # x ve ye 2 boyutlu numpy ternsörü
#     assert len(x.shape)==2
#     assert x.shape ==y.shape
    
#     x = x.copy
    
#     for i in range(x.shape[0]):
#         for j in range(x.shape[1]):
#             x[i, j] += y[i, j]
#         return x
    
# x = np.array([[[7, 14, 21],[7, 14 ,21],[7, 14 ,21]]])
# # x = np.array([7, 14, 21])

# # y = np.array([1, 1, 1])
# y = np.array([[[1, 1, 1],[2, 2 ,2],[3, 3 ,3]]])
# z = naive_add(x, y)
# print(z)
# x = [[1,2,3],[4,5,6],[7,8,9]]
# y = [[1,2,3],[4,5,6],[7,8,9]]
# z = naive_add(x, y)
# print(z)
x = np.array([[2, 3, 4],[0, 1, 22],[87, 8, 1]])
y = np.array([[10, 30, 45],[0, 12, 220],[8, 35, 16]])

z = x + y
print(z)

v=np.maximum(z,0)
print("v değeri: ")
print(v)
