# -*- coding: utf-8 -*-
"""
Created on Thu Jun 16 11:28:11 2022

@author: kbebim05
"""

import numpy as np

# # skaler sayı
# x = np.array(7)
# print(x)

# # # boyut görmek için
# # x.ndim
# # print(x.ndim)

# vektör yazalım
x = np.array = ([7, 14, 21])
print(x)


# # # a = x.ndim
# # # print(a)


# b = np.array([[[7, 14, 21],
#                 [7, 14 ,21]],
              
#               [[87, 89, 93],
#               [87, 89, 93]],
             
#               [[10, 4, 7]
#               [10, 4, 7]]])
# print(b)
# print(type(b))

# c = np.array = ([8, 9, 365])
# print(c)
# print(type(c))

from keras.datasets import mnist
(train_images, train_labels), (test_images, test_labels) = mnist.load_data()

print(train_images.shape)
print(train_images.ndim)

# print("test için: ")
# print(test_images.shape)
# print(test_images.ndim)
# print(test_images.dtype)

# train image görüntü
import matplotlib.pyplot as plt
digit = train_images[4]

plt.imshow(digit, cmap = plt.cm.binary)
plt.show()

# Eleman Temelli İşlem

def naive_add(x, y):
    # x ve ye 2 boyutlu numpy ternsörü
    assert len(x.shape)==2
    assert x.shape ==y.shape
    
    x = x.copy
    
    for i in range(x.shape[0]):
        for j in range(x.shape[1]):
            x[i, j] += y[i, j]
        return x
    
x = np.array([[7, 14, 21],
               [7, 14 ,21],
              [7, 14 ,21]])

y = np.array([[1, 1, 1],
               [2, 2 ,2],
              [3, 3 ,3]])
z = naive_add(x, y)
print(z)
