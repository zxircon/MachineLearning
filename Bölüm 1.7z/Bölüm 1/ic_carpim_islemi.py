# -*- coding: utf-8 -*-
"""
Created on Fri Jun 17 16:02:39 2022

@author: kbebim05
"""
import numpy as np

# İç Çarpım İşlemi

x = np.array([[3, 2],
             [1, 5]])

y = np.array([[1, 3],
             [0, 2]])

z = np.dot(x, y)
print(z)


# Kanal/Şekil Değiştirme

x = np.array([[0., 1.],
              [2., 3.],
              [4., 5.]])

print(x.shape)

print("---------")
x = x.reshape((2, 3))
print(x)

print("Transpoz")

x =np.zeros((100, 10))
x =np.transpose(x)
print(x.shape)


