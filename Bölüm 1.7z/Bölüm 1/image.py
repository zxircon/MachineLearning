# -*- coding: utf-8 -*-
"""
Created on Thu Jun 16 13:45:53 2022

@author: kbebim05
"""

import matplotlib.pyplot as plt
from keras.datasets import mnist
import numpy as np


(train_images, train_labels), (test_images, test_labels) = mnist.load_data()

print(train_images.shape)
print(train_images.ndim)

# train image görüntü
digit = train_images[25]

# plt.imshow(digit, cmap = plt.cm.binary)
plt.imshow(digit)
plt.show()

# belli aralıkta dizin

dizinim = train_images[526:890]
print(dizinim.shape)
